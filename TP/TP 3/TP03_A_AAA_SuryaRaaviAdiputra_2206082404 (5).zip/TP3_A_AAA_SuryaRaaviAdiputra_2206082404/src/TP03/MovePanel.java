package TP03;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// The display panel for a key events program -- arrow keys are used
// to move a stick figure around, the g key is used to make the figure
// grow by 50 % (increase in height by 50%), the s key causes the figure
// to shrink (to half its size)
public class MovePanel extends JPanel{
    private final int WIDTH = 600;
    private final int HEIGHT = 400;
    private final int JUMP = 5;

    // The following give the initial parameters for the figure
    private final int START_CENTER = WIDTH/2;
    private final int START_BOTTOM = HEIGHT - 40;
    private final int SIZE = HEIGHT / 2;

    private StickFigure stickMan;
    private int flag; // Variabel untuk menandai arm position

    // Constructor: Sets up the panel

    public MovePanel(){
        addKeyListener(new MoveListener());
        stickMan = new StickFigure(START_CENTER, START_BOTTOM, Color.blue, SIZE);
        setBackground(Color.black);
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setFocusable(true);
    }

    // Draws the figure

    public void paintComponent(Graphics page){
        super.paintComponent(page);
        if (flag == 1)
        {
            stickMan.setArmPosition(-20);
            stickMan.setLegPosition(15);
            stickMan.draw(page, 1);
        }
        else if (flag == 2)
        {
            stickMan.setArmPosition(-20);
            stickMan.setLegPosition(15);
            stickMan.draw(page, 2);
        }
        else {
            stickMan.draw(page, 0);
        }
    }

    // Represents a listener for keyboard activity.

    private class MoveListener implements KeyListener{

        // Handle a key-pressed event: arrow keys cause the
        // figure to move horizontally or vertically; the g
        // key causes the figure to "grow", the s key causes
        // the figure to shrink, the u key causes arms and
        // legs to go up, m puts them in the middle, and d
        // down.

        @Override
        public void keyPressed(KeyEvent event) {
            switch(event.getKeyCode()){
                case KeyEvent.VK_LEFT -> stickMan.move(-1 * JUMP, 0);
                case KeyEvent.VK_RIGHT -> stickMan.move(JUMP, 0);
                case KeyEvent.VK_DOWN -> stickMan.move(0, JUMP);
                case KeyEvent.VK_UP -> stickMan.move(0, -1 * JUMP);
                case KeyEvent.VK_G -> stickMan.grow(1.5);
                case KeyEvent.VK_S -> stickMan.shrink(0.5);
                case KeyEvent.VK_U -> {
                                            flag = 0;
                                            stickMan.setArmPosition(60);
                                            stickMan.setLegPosition(40);
                                      }
                case KeyEvent.VK_M -> {
                                            flag = 0;
                                            stickMan.setArmPosition(0);
                                            stickMan.setLegPosition(20);
                                      }
                case KeyEvent.VK_D -> {
                                         flag = 0;
                                         stickMan.setArmPosition(-60);
                                         stickMan.setLegPosition(10);
                                      }
                case KeyEvent.VK_L -> flag = 1;
                case KeyEvent.VK_R -> flag = 2;

                // Tambahan: Key B untuk mengembalikan lengan ke posisi awal.

                case KeyEvent.VK_B -> {
                                        flag = 0;
                                        stickMan.setArmPosition(-20);
                                        stickMan.setLegPosition(15);
                                      }
                default -> {}
            }
            repaint();
        }

        // Define empty bodies for key event methods
        // not used

        @Override
        public void keyTyped(KeyEvent e) {

        }

        @Override
        public void keyReleased(KeyEvent e) {

        }
    }
}

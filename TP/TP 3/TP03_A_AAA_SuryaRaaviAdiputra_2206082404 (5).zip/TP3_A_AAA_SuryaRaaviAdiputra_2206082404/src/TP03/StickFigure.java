package TP03;

import java.awt.*;

// Represents a graphical stick figure
public class StickFigure {
    private int baseX;  // Center of the figure
    private int baseY;  // Bottom of the feet
    private Color color;  // Color of the figure
    private int height;   // Height of the figure
    private int headW; // Width of the head
    private int legLength;  // Length of the legs
    private int legPosition;  // # Pixels the legs are up from vertical
    private int armLength;  // Horizontal length of the arms
    private int armToFloor;  // Distance from base to arms
    private int armPosition;  // # Pixels arm is above/below horizontal

    // Construct a stick figure given its four attributes

    public StickFigure(int center, int bottom, Color shade, int size){
        baseX = center;
        baseY = bottom;
        color = shade;
        height = size;

        // Define body positions proportional to height

        headW = height / 5;
        legLength = height / 2;
        armToFloor = 2 * height / 3;
        armLength = height / 3;

        // Set initial position of arms and legs
        armPosition = -20;
        legPosition = 15;
    }

    // Draw the figure

    public void draw(Graphics page, int flag){
        // Compute y-coordinate of top of head
        int top = baseY - height;
        page.setColor(color);

        // draw the head
        page.drawOval(baseX - headW/2, top, headW, headW);

        // Draw the trunk
        page.drawLine(baseX, top + headW, baseX, baseY - legLength);

        // Draw the legs
        page.drawLine(baseX, baseY - legLength, baseX - legPosition, baseY);
        page.drawLine(baseX, baseY - legLength, baseX + legPosition, baseY);

        // Draw the arms
        // Menambahkan parameter flag yang bertujuan untuk menandai posisi lengan
        // Flag = 1 untuk key l, flag = 2 untuk key r, sisanya untuk key u, m, dan d
        int startY = baseY - armToFloor;
        if (flag == 1){
            page.drawLine(baseX, startY, baseX - armLength, startY - armPosition);
            page.drawLine(baseX, startY, baseX - armLength, startY - armPosition - 15);
        }
        else if (flag == 2){
            page.drawLine(baseX, startY, baseX + armLength, startY - armPosition - 15);
            page.drawLine(baseX, startY, baseX + armLength, startY - armPosition);
        }
        else {
            page.drawLine(baseX, startY, baseX - armLength, startY - armPosition);
            page.drawLine(baseX, startY, baseX + armLength, startY - armPosition);
        }

    }


    // Move the figure -- first parameter gives the
    // number of pixels over (to right if over is positive)
    // to the left if over is negative) and up or down
    // (down if the parameter down is positive, up if it is
    // negative)

    public void move(int over, int down){
        baseX += over;
        baseY += down;
    }

    // Increase the height by given factor (if the
    // factor is > 1 the figure will "grow" else it will
    // shrink)

    public void grow(double factor){
        height = (int) (factor * height);

        // Reset body parts proportional to new height
        headW = height / 5;
        legLength = height / 2;
        armToFloor = 2 * height / 3;
        armLength = height / 3;
    }

    public void shrink(double factor){
        if (height > 100) {
            height = (int) (factor * height);

            // Mengatur ulang body dengan new height
            headW = height / 5;
            legLength = height / 2;
            armToFloor = 2 * height / 3;
            armLength = height / 3;
        }
    }

    // Set the legPosition(dist.from vertical) to
    // new value

    public void setLegPosition(int newPosition){
        legPosition = newPosition;
    }

    // Set the arm position to new value

    public void setArmPosition(int newPos){
        armPosition = newPos;
    }

}

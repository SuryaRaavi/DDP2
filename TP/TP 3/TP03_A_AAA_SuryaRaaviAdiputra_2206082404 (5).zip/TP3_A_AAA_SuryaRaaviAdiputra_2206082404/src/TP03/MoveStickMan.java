package TP03;

import javax.swing.*;
public class MoveStickMan {

    // Creates and displays the application frame.
    public static void main(String[] args) {
        JFrame frame = new JFrame("Moving a Stick Man with the Keyboard");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JButton button = new JButton("Tip");
        button.setToolTipText("You can manipulate the figure using keyboard (arrow keys, g key, s key, u key, d key, l key, r key, and m key)");
        button.setFocusable(false);
        MovePanel panel = new MovePanel();
        panel.add(button);
        frame.add(panel);

        frame.pack();

        frame.setVisible(true);
    }
}

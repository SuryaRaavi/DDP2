import javax.swing.*;

public class Main {

    // Membuat frame utama dan menambahkan panel yang digunakan untuk operasi ekspresi
    public static void main(String[] args) {
        JFrame frame = new JFrame("Infix->Postfix Evaluator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(new OperationPanel());
        frame.pack();
        frame.setSize(500, 200);
        frame.setVisible(true);
    }
}

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.StringTokenizer;


// Panel yang berfungsi untuk mengoperasikan ekspresi
public class OperationPanel extends JPanel{
    private JLabel infixLabel, postfixLabel, resultLabel, errorLabel;
    private JTextField infixTextField, postfixTextField, resultTextField, errorTextField;
    private ArrayList<String> stack;
    private ArrayList<String> element;
    private String postfixResult;
    private PostfixConverter converter;
    private ValidateExpression check;
    private boolean isAllowed;

    // Constructor yang digunakan untuk menentukan tampilan panel dan operasi pada panel
    public OperationPanel(){
        setBackground(Color.GRAY);
        setLayout(null);

        infixLabel = new JLabel("Enter Infix Expression: ");
        infixLabel.setFont(new Font("Arial", Font.BOLD, 12));
        infixLabel.setBounds(0, 10, 150, 20);
        add(infixLabel);

        infixTextField = new JTextField();
        infixTextField.setFont(new Font("Arial", Font.BOLD, 12));
        infixTextField.setBounds(200, 10, 180, 20);
        infixTextField.setBackground(Color.YELLOW);
        add(infixTextField);

        postfixLabel = new JLabel("Postfix Expression: ");
        postfixLabel.setFont(new Font("Arial", Font.BOLD, 12));
        postfixLabel.setBounds(0, 40, 150, 20);
        add(postfixLabel);

        postfixTextField = new JTextField();
        postfixTextField.setFont(new Font("Arial", Font.BOLD, 12));
        postfixTextField.setBounds(200, 40, 180, 20);
        postfixTextField.setBackground(Color.GRAY);
        postfixTextField.setEditable(false);
        postfixTextField.setBorder(null);
        add(postfixTextField);

        resultLabel = new JLabel("Result: ");
        resultLabel.setFont(new Font("Arial", Font.BOLD, 12));
        resultLabel.setBounds(0, 70, 150, 20);
        add(resultLabel);

        resultTextField = new JTextField();
        resultTextField.setFont(new Font("Arial", Font.BOLD, 12));
        resultTextField.setBounds(200, 70, 150, 20);
        resultTextField.setEditable(false);
        resultTextField.setBackground(Color.GRAY);
        resultTextField.setBorder(null);
        add(resultTextField);

        errorLabel = new JLabel("Error Messages: ");
        errorLabel.setFont(new Font("Arial", Font.BOLD, 12));
        errorLabel.setBounds(0, 100, 150, 20);
        add(errorLabel);

        errorTextField = new JTextField();
        errorTextField.setFont(new Font("Arial", Font.BOLD, 12));
        errorTextField.setText("[]");
        errorTextField.setEditable(false);
        errorTextField.setBackground(Color.GRAY);
        errorTextField.setBorder(null);
        errorTextField.setBounds(200, 100, 250, 20);
        add(errorTextField);


        // Menambahkan objek keyListener secara anonim untuk mengambil argumen dari infixTextField
        // ketika menekan enter
        infixTextField.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER){
                    this.infix2Postfix();
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {

            }

            // Argumen yang diinput di infixTextField akan diproses di method ini
            public void infix2Postfix() {
                String operation = infixTextField.getText();
                stack = new ArrayList<>();
                isAllowed = false;

                postfixResult = "";
                ExpressionStack expression = new ExpressionStack(stack);
                StringTokenizer token = new StringTokenizer(operation, "/*+-()^ ", true);
                element = new ArrayList<>();
                String val;

                // Mengambil dan menyimpan masing-masing digit dan operator yang dipisahkan oleh operator atau
                // whitespace
                boolean hasParentheses = false;
                while (token.hasMoreTokens()) {
                    val = token.nextToken();
                    if (val.matches("\\(|\\)")) {
                        hasParentheses = true;
                        element.add(val);
                    } else if (val.matches(".*(\\d).*|\\*|\\^|\\+|\\-|/|[a-zA-Z]+")) {
                        element.add(val);
                    }
                }

                check = new ValidateExpression(element);

                // Mengecek apakah ekspresi valid atau tidak
                switch (check.validate()) {
                    case "Division by Zero" -> {
                        postfixTextField.setText("/0");
                        resultTextField.setText("-");
                        errorTextField.setText("[Division by Zero]");
                    }
                    case "Missing open parenthesis" -> {
                        postfixTextField.setText("(");
                        resultTextField.setText("-");
                        errorTextField.setText("[Missing open parenthesis]");
                    }
                    case "Missing close parenthesis" -> {
                        postfixTextField.setText(")");
                        resultTextField.setText("-");
                        errorTextField.setText("[Missing close parenthesis]");
                    }
                    case "Cannot operate alphabet character" -> {
                        postfixTextField.setText("-[0-9]");
                        resultTextField.setText("-");
                        errorTextField.setText("[Cannot operate alphabet character]");
                    }
                    case "Missing operand" -> {
                        postfixTextField.setText("-[0-9]");
                        resultTextField.setText("-");
                        errorTextField.setText("[Missing operand]");
                    }
                    default -> isAllowed = true;
                }

                // Menerapkan try-catch apabila operasi valid, namun urutan penempatan
                // operand dan operator tidak tepat
                try {
                    if (isAllowed) {
                        errorTextField.setText("[]");
                        if (hasParentheses) {
                            converter = new PostfixConverter(this.parenthesesOperation(expression));
                            resultTextField.setText(converter.convert());
                        } else {
                            converter = new PostfixConverter(this.noParenthesesOperation(expression));
                            resultTextField.setText(converter.convert());
                        }
                    }
                } catch (Exception e) {
                    System.out.println("Not supported input");
                }
            }

            // Jika argumen memiliki karakter kurung, method ini akan dieksekusi
            public String parenthesesOperation(ExpressionStack expression){
                if (element.get(0).matches(".*(\\d).*")){
                    postfixResult += element.get(0);
                }

                // Pengulangan ini dibagi menjadi 2 if-else statement, yaitu saat argumen diawali dengan
                // kurung buka dan saat argumen diawali dengan operator
                for (int i = 0; i < element.size(); i++) {
                    if (element.get(i).matches("\\(") && element.get(i + 1).matches(".*(\\d).*")) {
                        postfixResult = postfixResult + " " + element.get(i + 1);
                    }
                    // Pada else if statement ini operasi dibagi 3 ketika elemen pertamanya operator, yaitu
                    // saat elemen kedua adalah karakter kurung buka, saat elemen ketiga adalah kurung tutup, dan saat
                    // elemen keduanya adalah operator juga
                    else if (!(element.get(i).matches(".*(\\d).*")) && !(element.get(i).matches("\\(|\\)"))) {
                        if (element.get(i + 1).equals("(")) {
                            expression.push(element.get(i));

                            // Push karakter "." untuk menandai atau membatasi operasi yang dilakukan di
                            // dalam kurung
                            expression.push(".");
                        }
                        else if (i != element.size() - 2) {
                            if (element.get(i + 2).equals(")")) {
                                postfixResult = postfixResult + " " + element.get(i + 1) + " " + element.get(i);
                                int size = expression.getSize();
                                if (size != 0){
                                    for (int j = 0; j < size; j++){
                                        if (!(expression.getTopElement().equals("."))){
                                            postfixResult = postfixResult + " " + expression.pop();
                                        }
                                        else{
                                            break;
                                        }
                                    }
                                }
                            }

                            // Saat elemen kedua setelah operator adalah operator juga
                            else {
                                if (element.get(i).equals(element.get(i + 2)) && element.get(i).equals("^")) {
                                    postfixResult = postfixResult + " " + element.get(i + 1);
                                    expression.push(element.get(i));
                                } else {
                                    switch (precedence(element.get(i), element.get(i + 2))) {
                                        case -1 -> {
                                            postfixResult = postfixResult + " " + element.get(i + 1);
                                            expression.push(element.get(i));
                                        }
                                        case 0 -> {
                                            postfixResult = postfixResult + " " + element.get(i + 1) + " " + element.get(i);
                                        }
                                        case 1 -> {
                                            postfixResult = postfixResult + " " + element.get(i + 1) + " " + element.get(i);
                                            int size = expression.getSize();
                                            if (expression.getSize() != 0) {
                                                for (int j = 0; j < size; j++){
                                                    if ((((precedence(expression.getTopElement(), element.get(i + 2)) == 1
                                                            || precedence(expression.getTopElement(), element.get(i + 2)) == 0))) &&
                                                            !(expression.getTopElement().equals("."))) {
                                                        postfixResult = postfixResult + " " + expression.pop();
                                                    }
                                                    else{
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Saat i sama dengan 2, else ini akan dieksekusi
                        else{
                            postfixResult = postfixResult + " " + element.get(i + 1) + " " + element.get(i);

                            int size = expression.getSize();
                            if (expression.getSize() != 0) {
                                for (int j = 0; j < size; j++) {
                                    if (!(element.get(i).matches("\\(|\\)")) && !(expression.getTopElement().equals("."))) {
                                        postfixResult = postfixResult + " " + expression.pop();
                                    }
                                    else{
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }

                // Setelah pengulangan selesai, akan dicek apakah masih ada elemen yang tersisa d stack
                // Jika ada, semua elemen tersebut akan di pop
                int size = expression.getSize();
                if (size != 0) {
                    for (int j = 0; j < size; j++) {
                        if (expression.getTopElement().equals(".")) {
                            expression.pop();
                        } else {
                            postfixResult = postfixResult + " " + expression.pop();
                        }
                    }
                }
                postfixTextField.setText(postfixResult);

                return postfixResult;
            }

            // Jika argumen tidak memiliki kurung, argumen ini akan dieksekusi
            public String noParenthesesOperation(ExpressionStack expression){
                postfixResult = element.get(0);
                for (int i = 1; i < element.size(); i++){

                    // Mendeteksi operasi berdasarkan letak operatornya
                    if (!element.get(i).matches(".*(\\d).*")){
                        if (i == element.size() - 2) {
                            postfixResult = postfixResult + " " + element.get(i + 1) + " " + element.get(i);

                            int size = expression.getSize();
                            if (expression.getSize() != 0) {
                                for (int j = 0; j < size; j++) {
                                    postfixResult = postfixResult + " " + expression.pop();
                                }
                            }
                        }
                        else if (element.get(i).equals(element.get(i + 2)) && element.get(i).equals("^")){
                                postfixResult = postfixResult + " " + element.get(i + 1);
                                expression.push(element.get(i));
                        }
                        else{

                            // Mengimplementasikan switch untuk membanding precedence dari dua operator
                            // menggunakan method precedence
                            switch(precedence(element.get(i), element.get(i + 2))){

                                //  Saat precedence operator i lebih kecil dari precedence operator i + 2
                                case -1 -> {
                                    postfixResult = postfixResult + " " + element.get(i + 1);
                                    expression.push(element.get(i));
                                }

                                //  Saat precedence operator i sama dengan precedence operator i + 2
                                case 0 -> {
                                    postfixResult = postfixResult + " " + element.get(i + 1) + " " + element.get(i);
                                }

                                //  Saat precedence operator i lebih besar dari precedence operator i + 2
                                case 1 -> {
                                    postfixResult = postfixResult + " " + element.get(i + 1) + " " + element.get(i);
                                    if(expression.getSize() != 0){
                                        int size = expression.getSize();
                                        for (int j = 0; j < size; j++){
                                            if (precedence(expression.getTopElement(), element.get(i + 2)) == 1
                                                    || precedence(expression.getTopElement(), element.get(i + 2)) == 0 ){
                                                postfixResult = postfixResult + " " + expression.pop();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                postfixTextField.setText(postfixResult);
                return postfixResult;
            }

            // Method untuk membandingkan precedence antara kedua operator
            public static int precedence(String operator1, String operator2){
                int priority1 = fillPrecedence(operator1);
                int priority2 = fillPrecedence(operator2);

                return Integer.compare(priority1, priority2);

            }

            // Method untuk mengisi precedence operator berdasarkan angka dimana
            // precedence tertingginya adalah kurung
            public static int fillPrecedence(String operator){
                int val = 0;
                switch(operator){
                    case "^" -> val = 5;
                    case "*", "/" -> val =  4;
                    case "+", "-" -> val = 3;
                    case "(", ")" -> val = 6;
                }
                return val;
            }

        });
    }


}

 import java.util.ArrayList;

// Class yang berfungsi untuk mengubah nilai postfix menjadi
 // hasil atau result
public class PostfixConverter {
    private ExpressionStack expression;
    private ExpressionStack stackPointer;
    private String postfixValue;
    private long operand1;
    private long operand2;
    private ArrayList<String> stack;
    private ArrayList<String> stack2;
    public PostfixConverter(String postfixResult){
        postfixValue = postfixResult;
    }

    // Pada method convert, operasi menggunakan dua stack dimana satu stack digunakan
    // untuk menghitung dan satu lagi digunakan untuk menyimpan value yang akan diambil
    public String convert() {
        String[] element = postfixValue.split(" ");
        stack = new ArrayList<>();
        stackPointer = new ExpressionStack(stack2);

        for (int i = element.length - 1; i >= 0; i--){
            if (!(element[i].equals("")))
            stackPointer.push(element[i]);
        }

        stack = new ArrayList<>();
        expression = new ExpressionStack(stack);

        while(stackPointer.getSize() > 0){
            if (stackPointer.getTopElement().matches(".*(\\d).*")){
                expression.push(stackPointer.pop());
            }
            else {
                    operand2 = Long.parseLong(expression.pop());
                    operand1 = Long.parseLong(expression.pop());
                    switch (stackPointer.getTopElement()) {
                        case "+" -> expression.push(String.valueOf(operand1 + operand2));
                        case "-" -> expression.push(String.valueOf(operand1 - operand2));
                        case "*" -> expression.push(String.valueOf(operand1 * operand2));
                        case "/" -> expression.push(String.valueOf(operand1 / operand2));
                        case "^" -> {
                            operand1 = (long) Math.pow(operand1, operand2);
                            expression.push(String.valueOf(operand1));
                        }
                    }
                    stackPointer.pop();
            }
        }
        return expression.pop();
    }


}

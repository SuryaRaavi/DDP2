import java.util.ArrayList;

// Class untuk mengimplementasikan stack secara LIFO
public class ExpressionStack {
    private String value;
    private ArrayList<String>  stack;
    public ExpressionStack(ArrayList<String> stack){
        this.stack = new ArrayList<>();
    }

    // Method untuk melakukan push elemen ke dalam stack
    public void push(String value){
        stack.add(value);
    }

    // Method untuk mengeluarkan elemen teratas dari stack
    public String pop(){
        value = stack.get(stack.size() - 1);
        stack.remove(stack.size() - 1);
        return value;
    }

    // Method yang mengembalikan panjang dari stack
    public int getSize(){
        return stack.size();
    }

    // Method yang mengembalikan elemen teratas dari stack
    public String getTopElement(){
        return stack.get(stack.size() - 1);
    }

}

import java.util.ArrayList;

// Class untuk mengecek apakah ekspresi valid atau tidak untuk dieksekusi
public class ValidateExpression {
    private ArrayList<String> expression;
    private int leftParentheses;
    private int rightParentheses;

    public ValidateExpression(ArrayList postfixResult){
        expression = postfixResult;
    }

    // Fungsi untuk mendeteksi apakah ekspresi memiliki jumlah kurung buka dan kurung
    // tutup yang sama atau tidak
    public boolean lackOfParentheses(){
        leftParentheses = 0;
        rightParentheses = 0;
        for (int i = 0; i < expression.size(); i++){
            if (expression.get(i).equals("(")){
                leftParentheses++;
            }
            else if (expression.get(i).equals(")")){
                rightParentheses++;
            }
        }
        return rightParentheses != leftParentheses;
    }

    // Fungsi untuk mendeteksi apakah ekspresi memiliki operan yang
    // cukup atau tidak
    public boolean lackOfOperand(){
        int countOperand = 0;
        int countOperator = 0;
        for (int i = 0; i < expression.size(); i++){
            if (expression.get(i).matches(".*(\\d).*")){
                countOperand++;
            }
            else if (expression.get(i).matches("\\*|\\^|\\+|\\-|/")){
                countOperator++;
            }
        }
        return countOperator != (countOperand - 1);
    }

    // Fungsi untuk mendeteksi apakah ada pembagi 0 di ekspresi
    public boolean divisionByZero(){
        for (int i = 0; i < expression.size(); i++){
            if (expression.get(i).equals("/") && expression.get(i + 1).equals("0")){
                return true;
            }
        }
        return false;
    }

    //
    public boolean alphabetOperand(){
        for (int i = 0; i < expression.size(); i++){
            if (expression.get(i).matches("[a-zA-Z]+")){
                return true;
            }
        }
        return false;
    }

    // Fungsi untuk memvalidasi apakah ekspresi memenuhi semua fungsi
    // error sebelumnya
    public String validate(){
        if (this.divisionByZero()){
            return "Division by Zero";
        }
        else if (this.lackOfParentheses()){
            if (leftParentheses > rightParentheses){
                return "Missing close parenthesis";
            }
            else{
                return "Missing open parenthesis";
            }
        }
        else if (this.alphabetOperand()){
            return "Cannot operate alphabet character";
        }
        else if (this.lackOfOperand()){
            return "Missing operand";
        }
        else{
            return "true";
        }
    }
}

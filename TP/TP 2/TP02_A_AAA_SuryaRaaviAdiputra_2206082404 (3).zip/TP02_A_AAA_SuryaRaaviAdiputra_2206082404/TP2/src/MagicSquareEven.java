public class MagicSquareEven
{
    private static int n;
    private static int[][] square;
    public int startPoint = 1;

    public MagicSquareEven(int s)
    {
        n = s;
        square = new int[n][n];
    }

    /* Method generateSquare berfungsi untuk menghasilkan magic square ganjil dimana
       dimulai dari baris 0 dan kolom n / 2 apabila input yang dimasukkan bil genap
       singly even (6, 10, ...)*/
    public int[][] generateSquare(int n)
    {
        int[][] arr = new int[n][n];
        int row = 0;
        int column = n / 2;
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                int newRow = (row - 1 + n) % n;
                int newColumn = (column + 1) % n;
                arr[row][column] = startPoint;
                startPoint++;
                if (arr[newRow][newColumn] == 0)
                {
                    row = newRow;
                    column = newColumn;
                }
                else
                {
                    row = (row + 1) % n;
                }
            }
        }
        return arr;
    }

    /* value yang ada pada sub square pada input singly even akan dimasukkan pada variabel square
       menggunakan method ini*/
    public static void assignValue(int row, int column, int startPosRow, int startPosColumn, int[][] mainArray, int[][] copyArray)
    {
        int x = 0;
        int y = 0;
        for (int i = startPosRow; i < row; i++)
        {
            for (int j = startPosColumn; j < column; j++)
            {
                mainArray[i][j] = copyArray[x][y];
                y = (y + 1) % (n / 2);
            }
            x = (x + 1) % (n / 2);
        }
    }
    // Membuat magic square apabila input adalah bil genap doubly even (4, 8, ...)
    public void doublyEven()
    {
        /* Penggunaan for loop ini pada dasarnya berfungsi untuk menukar value pada baris dan kolom
           0 sampai n / 4 dan baris dan kolom n > n - (n / 4).*/
        for (int i = 0; i < square.length; i++)
        {
            for (int j = 0; j < square.length; j++)
            {
                int val = n * i + j + 1;
                square[i][j] = val;
            }
        }
        for (int i = (n / 4); i < n - (n / 4); i++)
        {
            for (int k = 0 ; k < n; k++)
            {
                if ((k < n / 4 || k >= n - (n / 4)) && (i < n / 2))
                {
                    int temp = square[i][k];
                    square[i][k] = square[n - (n / 4) - 1 - (i - (n / 4))][k];
                    square[n - (n / 4) - 1 - (i - (n / 4))][k] = temp;
                }

            }
            for (int j = 0; j < n; j++)
            {
                if (j < n / 4)
                {
                    int temp = square[i][j];
                    square[i][j] = square[i][n - j - 1];
                    square[i][n - j - 1] = temp;
                }
            }
        }
        for (int i = 0; i < n; i++)
        {
            for (int k = n / 4; k < n - (n / 4); k++)
            {
                if ((k < (n / 2) )&& (i < n / 4))
                {
                    int temp = square[i][k];
                    square[i][k] = square[i][n - k - 1];
                    square[i][n - k - 1] = temp;
                    int temp2 = square[n - 1 - i][k];
                    square[n - 1 - i][k] = square[n - 1 - i][n - k - 1];
                    square[n - 1 - i][n - k - 1] = temp2;
                }
            }
            for (int j = n / 4; j < n - (n / 4); j++)
            {
                if (i < (n / 4))
                {
                    int temp = square[i][j];
                    square[i][j] = square[n - i - 1][j];
                    square[n - i - 1][j] = temp;
                }

            }
        }
    }

    public void singlyEven()
    {
        int x = (n - 2) / 4;
        int halfSize = n / 2;

        /* Membagi kotak menjadi 4 sub kotak dan setiap sub kotak dicari megic squarenya
           menggunakan algoritma magic square ganjil. */
        int[][] subSquare_1 = generateSquare(halfSize);
        int[][] subSquare_4 = generateSquare(halfSize);
        int[][] subSquare_2 = generateSquare(halfSize);
        int[][] subSquare_3 = generateSquare(halfSize);

        /* Menukar value pada sub square 1 kuadran 2 dan sub square 3 kuadran 3
           pada rentang kolom 0 sampai x dan baris 0 sampai n - 1. */
        for (int i = 0; i < halfSize; i++)
        {
            for (int j = 0; j < x; j++)
            {
                if (i != halfSize / 2 || j != (halfSize / 2) - 1)
                {
                    int temp = subSquare_1[i][j];
                    subSquare_1[i][j] = subSquare_3[i][j];
                    subSquare_3[i][j] = temp;
                }
            }
        }

        /* If statemment untuk menukar sub square 2 kuadran 1 dan sub square 4 kuadran 4
           pada rentang kolom n sampai n - x - 1 dan baris 0 sampai n - 1*/
        if (x - 1 > 0)
        {
            for (int i = 0; i < halfSize; i++)
            {
                for (int j = halfSize - 1; j > halfSize - x; j--)
                {
                    int temp = subSquare_4[i][j];
                    subSquare_4[i][j] = subSquare_2[i][j];
                    subSquare_2[i][j] = temp;
                }
            }
        }

        int temp = subSquare_1[halfSize / 2][halfSize / 2];
        subSquare_1[halfSize / 2][halfSize / 2] = subSquare_3[halfSize / 2][halfSize / 2];
        subSquare_3[halfSize / 2][halfSize / 2] = temp;
        assignValue(halfSize, halfSize, 0, 0, square, subSquare_1);
        assignValue(halfSize, n, 0, halfSize, square, subSquare_2);
        assignValue(n, halfSize, halfSize, 0, square, subSquare_3);
        assignValue(n, n, halfSize, halfSize, square, subSquare_4);
    }

    // Method untuk menghitung jumlah value berdasarkan salah satu baris dari magic square
    public int rowSum(int n)
    {
        int sum = 0;
        for (int i = 0; i < square.length; i++)
        {
            for (int j = 0; j < square.length; j++)
            {
                if (i == n)
                {
                    sum += square[i][j];
                }
            }
        }
        return sum;
    }

    // Method untuk menghitung jumlah value berdasarkan salah satu kolom dari magic square
    public int columnSum(int n)
    {
        int sum = 0;
        for (int i = 0; i < square.length; i++)
        {
            for (int j = 0; j < square.length; j++)
            {
                if (n == j)
                {
                    sum += square[i][j];
                }
            }
        }
        return sum;
    }

    // Method untuk menghitung jumlah value berdasarkan salah satu diagonal dari magic square.
    public int diagonalSum()
    {
        int sum = 0;
        for (int i = 0; i < square.length; i++)
        {
            for (int j = 0; j < square.length; j++)
            {
                if (i == j)
                {
                    sum += square[i][j];
                }
            }
        }
        return sum;
    }

    // Method yang akan mengembalikan representasi string dari magic square.
    public String toString()
    {
        String r = "";
        for (int i = 0; i < square.length; i++)
        {
            for (int j = 0; j < square.length; j++)
            {
                r = r + "\t" + square[i][j];
            }
            r += "\n\n";
        }
        return r;
    }
    public static void main (String[] args)
    {

        // Memproses input dari command line.
        if (args.length == 1) {

            /* try-catch untuk meng-handle apabila input yang dimasukkan bukan
               bertipe integer atau input yang dimasukkan <= 0. */
            int n = 0;
            try {
                if (Integer.parseInt(args[0]) > 0) {
                    n = Integer.parseInt(args[0]);

                    // Membuat  objek magic square.
                    MagicSquareEven obj = new MagicSquareEven(n);
                    if (Integer.parseInt(args[0]) % 4 == 0) {
                        obj.doublyEven();
                        System.out.println("\nMagic Square of size " + n + "x" + n + ":\n\n" + obj +
                                "\nMain diagonal sum: " + obj.diagonalSum() +
                                "\nColumn sum: " + obj.columnSum(0) +
                                "\nRow sum: " + obj.rowSum(n - 1) + "\n");
                    } else if (Integer.parseInt(args[0]) == 2) {
                        System.out.println("Input harus bilangan genap lebih besar dari 2");
                    } else if ((Integer.parseInt(args[0]) - 2) % 4 == 0) {
                        obj.singlyEven();
                        System.out.println("\nMagic Square of size " + n + "x" + n + ":\n\n" + obj +
                                "\nMain diagonal sum: " + obj.diagonalSum() +
                                "\nColumn sum: " + obj.columnSum(0) +
                                "\nRow sum: " + obj.rowSum(n - 1) + "\n");
                    } else {
                        System.out.println("Usage: java -jar <jarFile> <even size of square>");
                    }
                }
                else
                {
                    System.out.println("Usage: java -jar <jarFile> <even size of square>");
                }
            } catch (Exception e) {
                System.out.println("Usage: java -jar <jarFile> <even size of square>");
            }
        }
        else
        {
            System.out.println("Usage: java -jar <jarFile> <even size of square>");
        }
    }
}


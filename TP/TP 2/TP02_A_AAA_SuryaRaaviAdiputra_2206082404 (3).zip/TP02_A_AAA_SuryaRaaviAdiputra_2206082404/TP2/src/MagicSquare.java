public class MagicSquare
{
    private int[][] square;
    private int size;
    /**
     Construct a MagicSquare object
     (precondition: s is odd).
     @param s the size of the square
     */
    public MagicSquare(int s)
    {
        size = s;
        square = new int[size][size];

    }
    /**
     Find the sum of the diagonal.
     @return sum: the sum of the diagonal
     */
    public int diagonalSum()
    {
        int sum = 0;
        for (int ii = 0; ii < square.length; ii++)
        {
            for (int j = 0; j < square.length; j++)
            {
                if (ii == j || (ii + j) % size == (size - 1))
                {
                    sum += square[ii][j];
                }
            }
        }
        return (sum + square[size / 2][size / 2]) / 2;
    }
    /**
     Add the numbers in a column of the square.
     @param i the column index
     @return the sum of the column
     */
    public int columnSum(int i)
    {
        int sum = 0;
        for (int[] ints : square) {
            for (int j = 0; j < square.length; j++) {
                if (j == i) {
                    sum += ints[j];
                }
            }
        }
        return sum;
    }
    /**
     Add the numbers in a row of the square.
     @param i the row index
     @return the sum of the row
     */
    public int rowSum(int i)
    {
        int sum = 0;
        for (int ii = 0; ii < square.length; ii++)
        {
            for (int j = 0; j < square.length; j++)
            {
                if (ii == j)
                {
                    sum += square[ii][j];
                }
            }
        }
        return sum;
    }

    /**
     Gets a string representation of the contents of this square.
     @return a string represenation of the square
     */
    public String toString()
    {
        String r = "";
        int row = size - 1;
        int column = size / 2;
        for (int i = 0; i < square.length; i++)
        {
            for (int j = 0; j < square.length; j++)
            {
                int nilai = size * i + j + 1;
                square[row][column] = nilai;
                int nextRow = (size + 1 + row) % size;
                int nextColumn = (column + 1) % size;
                if (square[nextRow][nextColumn] == 0)
                {
                    row = nextRow;
                    column = nextColumn;
                }
                else
                {
                    row = (row  - 1) % size;
                }

            }
        }
        for (int i = 0; i < square.length; i++)
        {
            for (int j = 0; j < square.length; j++)
            {
                r = r + "\t" + square[i][j];
            }
            r += "\n\n\n";
        }
        return r;
    }
}


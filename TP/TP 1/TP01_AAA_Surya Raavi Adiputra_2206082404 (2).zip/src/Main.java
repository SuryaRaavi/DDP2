import javax.swing.JOptionPane;
public class Main
{
    /* Method ini akan mengembalikan nilai boolean berdasarkan prefix dan jumlah digit
        yang sudah ditentukan sebelumnya*/
    public static boolean isValid(long number)
    {
        if (getSize(number) >= 13 && getSize(number) <= 16)
        {
            if (prefixMatched(number, 4)  || prefixMatched(number, 5)  || prefixMatched(number, 6) ||
                    prefixMatched(number, 37))
            {return true;}
            else
            {return false;}
        }
        else
        {return false;}
    }
    /* Method ini bertujuan untuk mengalikan digit index genap dengan 2
        lalu menambahkan seluruh digitnya*/
    public static int sumOfDoubleEvenPlace(long number)
    {
        int sumOfNumberEven = 0;
        String number2 = Long.toString(number);
        String number3 = "";
        for (int i = 0; i < getSize(number) ; i++)
        {number3 = Character.toString(number2.charAt(i)) + number3;}
        for (int j = 1; j < getSize(number) + 1; j++)
        {
            if (j % 2 == 0)
            {
                int mul = 2 * Integer.parseInt(Character.toString(number3.charAt(j-1)));
                sumOfNumberEven += getDigit(mul);
            }
        }
        return sumOfNumberEven;
    }
    /* Method untuk mengembalikan satu sampai dua digit pertama dari number*/
    public static int getDigit(int number)
    {
        int sumOfDigit = 0;
        String str_num = Integer.toString(number);
        if (str_num.length() == 2)
        {return Integer.parseInt(str_num.substring(0, 1)) + Integer.parseInt(str_num.substring(1));}
        else
        {return number;}
    }
    /* Method untuk menghitung total dari digit dengan index ganjil*/
    public static int sumOfOddPlace(long number)
    {
        int sumOfNumberOdd = 0;
        String number2 = Long.toString(number);
        String number3 = "";
        for (int i = 0; i < getSize(number) ; i++)
        {number3 = Character.toString(number2.charAt(i)) + number3;}
        for (int j = 1; j < getSize(number) + 1; j++)
        {
            if (j % 2 == 1)
            {
                int val = Integer.parseInt(Character.toString(number3.charAt(j-1)));
                sumOfNumberOdd += val;
            }
        }
        return sumOfNumberOdd;
    }
    /* Method ini bertujuan untuk mencocokkan prefix yang diambil dari method getPrefix*/
    public static boolean prefixMatched(long number, int d)
    {
        if (getPrefix(number, 1) == d || getPrefix(number, 2) == d  )
        {return true;}
        else
        {return false;}
    }
    /* Method ini bertujuan mengembalikan banyaknya digit dari input bertipe long*/
    public static int getSize(long d)

    {
        return Long.toString(d).length();
    }
    /* Method ini bertujuan untuk mengembalikan prefix dari number sejumlah k
     dimana k ini minimal 1 dan maksimal 2*/
    public static long getPrefix(long number, int k)
    {
        String number2 = Long.toString(number);
        return Integer.parseInt(number2.substring(0, k));
    }
    /* Method ini akan mengembalikan total dari penjumlahan digit genap dan ganjil */
    public static int sumOfEvenAndOdd(long number)
    {
        return sumOfDoubleEvenPlace(number) + sumOfOddPlace(number);
    }

    public static void main(String[] args)
    {
        /* Membuat objek untuk method main*/
        Main obj = new Main();
        boolean isTrue = true;
        while (isTrue)
        {
            String input = JOptionPane.showInputDialog(null,
                    "Enter a credit card / debit card number as a long integer, \nQUIT to end: ",
                    "Validation of credit card / debit card numbers",
                    JOptionPane.INFORMATION_MESSAGE);
            /* Jika input kosong maka akan menjalankan if statement
              , jika input quit maka program akan berhenti */
            if (input == null)
            {
                System.out.println("");
            }
            else if (input.equalsIgnoreCase("QUIT"))
            {
                isTrue = false;
                System.exit(0);
            }
            else {
                /*Menggunakan try-exception untuk meng-handle input yang bukan
                bertipe long*/
                try {
                    long number = Long.parseLong(input);
                    if (obj.isValid(number)) {
                        int total = sumOfEvenAndOdd(number);
                        if (total % 10 == 0) {
                            String text = "The number " + number + " is valid";
                            JOptionPane.showMessageDialog(null, text,
                                    "Validation of credit card / debit card numbers",
                                    JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            String text = "The number " + number + " is invalid";
                            JOptionPane.showMessageDialog(null, text,
                                    "Validation of credit card / debit card numbers",
                                    JOptionPane.INFORMATION_MESSAGE);
                        }
                    } else {
                        String text = "The number " + number + " is invalid";
                        JOptionPane.showMessageDialog(null, text,
                                "Validation of credit card / debit card numbers",
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                catch (Exception e)
                {
                    JOptionPane.showMessageDialog(null, "Input yang dimasukkan tidak valid",
                            "Validation of credit card / debit card numbers",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            }
        }
    }
}
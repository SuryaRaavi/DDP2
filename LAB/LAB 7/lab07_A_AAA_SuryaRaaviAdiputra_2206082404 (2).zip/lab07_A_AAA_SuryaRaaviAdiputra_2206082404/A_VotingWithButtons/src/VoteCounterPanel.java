import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class VoteCounterPanel extends JPanel{
    private int votesForJoe;
    private JButton joe;
    private JLabel labelJoe;
    private int votesForSam;
    private JButton sam;
    private JLabel labelSam;
    private int votesForMary;
    private JButton mary;
    private JLabel labelMary;
    // Constructor: Sets up the GUI.
    public VoteCounterPanel(){
        // Menggunakan BoxLayout untuk mengatur letak komponen secara vertikal tengah

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        add(Box.createVerticalGlue());

        // Mengatur komponen menggunakan method createRigidArea agar tepat ditengah secara horizontal dan
        // memberikan jarak secara vertikal

        add(Box.createRigidArea(new Dimension(135, 0)));
        add(Box.createRigidArea(new Dimension(0, 10)));
        votesForJoe = 0;
        joe = new JButton("Vote for Joe");
        joe.addActionListener(new JoeButtonListener());
        labelJoe = new JLabel("Votes for Joe " + votesForJoe);
        add(joe);
        add(labelJoe);

        add(Box.createRigidArea(new Dimension(135, 0)));
        add(Box.createRigidArea(new Dimension(0, 10)));
        votesForSam = 0;
        sam = new JButton("Vote for Sam");
        sam.addActionListener(new SamButtonListener());
        labelSam = new JLabel("Votes for Sam " + votesForSam);
        add(sam);
        add(labelSam);

        add(Box.createRigidArea(new Dimension(135, 0)));
        add(Box.createRigidArea(new Dimension(0, 10)));

        votesForMary = 0;
        mary = new JButton("Vote for Mary");
        mary.addActionListener(new MaryButtonListener());
        labelMary = new JLabel("Votes for Mary " + votesForMary);
        add(mary);
        add(labelMary);

        add(Box.createVerticalGlue());
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setPreferredSize(new Dimension(400, 400));
        setBackground(Color.cyan);
    }
    // Represents a listener for button push (action) events
    private class JoeButtonListener implements ActionListener{
        // Updates the counter and label when Vote for Joe
        // button is pushed
        public void actionPerformed(ActionEvent event){
            votesForJoe++;
            labelJoe.setText("Votes for Joe: " + votesForJoe);
        }
    }
    private class SamButtonListener implements ActionListener{
        // Updates the counter and label when Vote for Sam
        // button is pushed
        public void actionPerformed(ActionEvent event){
            votesForSam++;
            labelSam.setText("Votes for Sam: " + votesForSam);
        }
    }
    private class MaryButtonListener implements ActionListener{
        // Updates the counter and label when Vote for Mary
        // button is pushed
        public void actionPerformed(ActionEvent event){
            votesForMary++;
            labelMary.setText("Votes for Mary: " + votesForMary);
        }
    }
}

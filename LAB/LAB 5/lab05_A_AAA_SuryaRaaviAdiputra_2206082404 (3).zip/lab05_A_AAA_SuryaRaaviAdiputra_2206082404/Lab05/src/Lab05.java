import java.util.Scanner;
// ****************************************************************
// Lab05.java
//
// Provide a menu-driven program for processing a random integer array.
//
// ****************************************************************
public class Lab05 {
    // ------------------------------------------------------------------
    // Creates a random list of integers, then repeatedly print the menu
    // and do what the user asks until they quit.
    // ------------------------------------------------------------------
    public static void main(String[] args) {
        int[] list = new int[10]; //initial default array
        Scanner scan = new Scanner(System.in);

        /* Menggunakan try-exception untuk mengatasi error yang terjadi
           saat user menginput bilangan yang bukan bertipe integer
         */
        printMenu();
        try {
            int choice = scan.nextInt();
            while (choice != 0) {
                try {
                    int loc;
                    switch (choice) {
                        case 1 -> {
                            System.out.println("How many elements?");
                            int size = scan.nextInt();
                            list = new int[size];
                            randomize(list);
                        }
                        case 2 -> selectionSort(list);
                        case 3 -> {
                            if (list[0] == 0) {
                                System.out.println("List masih kosong!");
                            } else {
                                System.out.print("Enter the value to look for: ");
                                loc = linearSearch(list, scan.nextInt());
                                if (loc != -1) {
                                    System.out.printf("Found at location %d\n", loc);
                                } else {
                                    System.out.println("Not in the list");
                                }
                            }
                        }
                        case 4 -> {
                            if (list[0] == 0) {
                                System.out.println("List masih kosong!");
                            } else {
                                printList(list);
                            }
                        }
                        default -> System.out.println("Sorry, invalid choice");
                    }
                } catch (Exception e) {
                    System.out.println("Sorry, invalid choice");
                }
                printMenu();
                choice = scan.nextInt();
            }
            System.out.println("Bye!");
        }
        catch (Exception e)
        {
            System.out.println("Sorry, invalid choice");
        }
    }
    // -------------------------------------
    // Prints the menu of user's choices.
    // -------------------------------------
    public static void printMenu() {
        System.out.println("\n Menu ");
        System.out.println(" ====");
        System.out.println("0: Quit");
        System.out.println("1: Create a new list of random elements");
        System.out.println("2: Sort the list using selection sort");
        System.out.println("3: Find an element in the list using linear search");
        System.out.println("4: Print the list");
        System.out.print("\nEnter your choice: ");
    }
    // ------------------------------------------------------------------
    // Fills the array with random integers between 1 and 1000, inclusive
    // ------------------------------------------------------------------
    public static void randomize(int[] list)
    {
        for (int i = 0; i < list.length; i++)
        {
            list[i] = 1 + (int) (Math.random() * 1000);
        }
    }
    // ----------------------------------------
    // Prints array elements with indices
    // ----------------------------------------
    public static void printList(int[] list) {
        for (int i = 0; i < list.length; i++)
            System.out.printf("[%d] : %2d\n", i, list[i]);
    }
    // -----------------------------------------------------------------
    // Returns the index of the first occurrence of target in the list, -1
    // if target does not appear in the list.
    // -----------------------------------------------------------------
    public static int linearSearch(int[] list, int target) {
        return linearSearchRec(list, target, 0);
    }
    // -----------------------------------------------------------------
    // Recursive implementation of the sequential search -- searches
    // for target starting at index lo.
    // Is this method tail-recursive?
    // -----------------------------------------------------------------
    private static int linearSearchRec(int[] list, int target, int lo) {
        /* me-recursive list dengan menambahkan 1 pada variabel lo
           yang menjadi index dari list*/
        if (lo >= list.length) // target not found
            return -1;
        else if (list[lo] == target) // target found
            return lo;
        else // keep searching recursively
            return linearSearchRec(list, target, lo + 1);
    }
    // ------------------------------------------------------------------------
    // Sorts the list into ascending order using the selection sort algorithm.
    // ------------------------------------------------------------------------
    public static void selectionSort(int[] list) {
        int minIndex;
        for (int i = 0; i < list.length - 1; i++) {
            //find smallest element in list starting at location i
            minIndex = i;
            /* Iterasi untuk menukar suatu list index i dengan list
               index i + 1 apabila list[i] > list [i+1]*/
            for (int j = i + 1; j < list.length; j++)
            {
                int temp = list[minIndex];
                if (list[j] < temp)
                {
                    list[minIndex] = list[j];
                    list[j] = temp;
                }
            }
        }
    }
}

import java.util.Scanner;

public class Circle {
    public static void main(String[] args) {
        
        final double PI = Math.PI; //3.141592653589793
        Scanner scan = new Scanner(System.in);

        System.out.print("Please enter a value for the radius : ");
        double radius = scan.nextDouble();
        double area = PI * radius * radius;
        double circumference = PI * 2 * radius;
        System.out.println("The area of a circle with radius " + radius + " is " + area);
        System.out.println("The circumference of a circle with radius " + radius + " is " + circumference);

        System.out.print("Please enter a value for the radius : ");
        radius = scan.nextDouble();
        area = PI * radius * radius;
        circumference = PI * 2 * radius;
        System.out.println("The area of a circle with radius " + radius + " is " + area);
        System.out.println("The circumference of a circle with radius " + radius + " is " + circumference);

        scan.close();
    }
}